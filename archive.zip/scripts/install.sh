#!/bin/bash

# Replace with the GitHub repo URL and the release tag you want to download
REPO_URL="https://github.com/iamnator/envy"
RELEASE_TAG="v1.0.0"

# Prompt the user for the secret value
read -p "Enter the value for the secret environment variable: " SECRET_VALUE

# Download the binary from the GitHub release
DOWNLOAD_URL="$REPO_URL/releases/download/$RELEASE_TAG/envy"
sudo curl -L "$DOWNLOAD_URL" -o /usr/local/bin/envy
sudo chmod +x /usr/local/bin/envy

# Create the service file if it doesn't exist
if [ ! -f /etc/systemd/system/envy.service ]; then
    sudo touch /etc/systemd/system/envy.service
fi

# Update the service file with the unit definition
sudo bash -c "cat >/etc/systemd/system/envy.service" <<EOF
[Unit]
Description=Environment Manager
Wants=network.target
After=syslog.target network-online.target

[Service]
Environment="SECRET=$SECRET_VALUE"
Type=simple
ExecStart=/usr/local/bin/envy
StandardOutput=file:/var/log/envy-service/envy-service.log
StandardError=file:/var/log/envy-service/envy-service.log
Restart=on-failure
RestartSec=10
KillMode=process

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd daemon to pick up the changes
sudo systemctl daemon-reload

# Start the service
sudo systemctl start envy.service

# Enable the service to start at boot
sudo systemctl enable envy.service